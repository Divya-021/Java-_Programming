package com.kiet.javaTest;
import com.kiet.javaDemo.C1;
public class PubC extends C1{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//C1 ob=new C1();
		PubC ob=new PubC();
		ob.c=20;
		ob.inc();
	}

}

package com.kiet.javaDemo;

public interface IntB{
void meth2();
}

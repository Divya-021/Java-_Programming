package com.kiet.javaDemo;

public interface IntA {
	//int a=10;
void method1();
}

package com.kiet.javaDemo;
class B1 {
int b;
void in()
{
	System.out.println("b: "+b);
}
}

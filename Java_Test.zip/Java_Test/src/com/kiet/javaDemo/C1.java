package com.kiet.javaDemo;

public class C1 {
protected int c;
protected void inc()
{
	System.out.println("c: "+c);
}
}
